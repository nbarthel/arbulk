import React from 'react';
import '../../public/stylesheets/style.css';
class Footer extends React.Component {
  render(){
        return (
        	   <footer className="pos-relative-b">
                <div className="container">
                    <p className="Copyright">@2016 Copyright. AR BulkPak. All RIghts Reserved</p>
                </div>
            </footer>
           )
    }
}
export default Footer;