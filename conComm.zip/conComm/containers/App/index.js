import React from 'react';


function App(props) {
	return (
		<div>
		{props.children}
		</div>
		)
}


export default App;