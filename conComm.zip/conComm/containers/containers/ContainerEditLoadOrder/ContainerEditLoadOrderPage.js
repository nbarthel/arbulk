import React from 'react';
import ContainerEditLoadOrderForm from './ContainerEditLoadOrderForm';
class ContainerEditLoadOrderPage  extends React.Component{
    render(){
        return(
            <div>
                <ContainerEditLoadOrderForm/>
            </div>
        );


    }
}
export default ContainerEditLoadOrderPage;