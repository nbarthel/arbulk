import React from 'react';
import ContainerDetailsForm from './ContainerDetailsForm';
class ContainerDetailsPage  extends React.Component{
    render(){
        return(
            <div>
                <ContainerDetailsForm/>
            </div>
        );


    }
}
export default ContainerDetailsPage;