'use strict';

module.exports = function(Tlocation) {

};
