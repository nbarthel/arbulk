'use strict';

module.exports = function(Tstate) {

};
