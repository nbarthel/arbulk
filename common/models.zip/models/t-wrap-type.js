'use strict';

module.exports = function(Twraptype) {

};
