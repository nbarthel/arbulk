'use strict';

module.exports = function(Newmodel) {

};
