'use strict';

module.exports = function(Tpiinventory) {

};
