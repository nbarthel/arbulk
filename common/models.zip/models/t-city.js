'use strict';

module.exports = function(Tcity) {

};
