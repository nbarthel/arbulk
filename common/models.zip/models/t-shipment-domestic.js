'use strict';

module.exports = function(Tshipmentdomestic) {

};
