'use strict';

module.exports = function(Tservices) {

};
