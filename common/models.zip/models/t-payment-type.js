'use strict';

module.exports = function(Tpaymenttype) {

};
