/**
 * Created by Anurag on 26-10-2016.
 */
var loopback = require('loopback');
var dateFormat = require('dateformat');
var ModelBuilder = require('loopback-datasource-juggler').ModelBuilder;
var modelBuilder = new ModelBuilder();
var dsConfig = require('../../server/datasources.json');
module.exports = function(Tshipmentent) {
//    // var currentUser = context && context.get('currentUser');

    Tshipmentent.createShipMentEntry = function (tshipment, cb) {
        var shipmentLots = Tshipmentent.app.models.TShipmentLots;
        var shipmentDomestic = Tshipmentent.app.models.TShipmentDomestic;
        var shipmentInternational = Tshipmentent.app.models.TShipmentInternational;
        var shipmentAddress = Tshipmentent.app.models.TShipmentAddress;
        var ds = Tshipmentent.dataSource;
        var customErr = new Error();
        customErr.statusCode = 422;
        customErr.message = null;
        console.log('>>>>>>>>>..lotlength' , tshipment.lotInformation.length)
        console.log('>>>>>>>>>..addlengthhh' , tshipment.Address.length)

        Tshipmentent.create({
                "id": 0,
                "customerId": tshipment.SI.customer_id,
                "releaseNumber": tshipment.SI.releaseNumber,
                "numberOfContainers": tshipment.SI.numberOfContainers,
                "numberOfBags": tshipment.SI.numberOfBags,
                "isDomestic":tshipment.SI.isDomestic ,
                "shipmentComplete": 0,
                "confirmation": "string",
                "createdBy": tshipment.SI.created_By,
                "createdOn": tshipment.SI.created_on,
                "midifiedBy": 0,
                "modifiedOn": null,
                "active": 0

            },
            function (err, obj) {
                if (err) {
                    console.log(">>>>>" , err)
                    return cb(null, {errors: err});
                }
                console.log("obj>>>>>>>>>>> after shipment" ,obj)
                if(obj){
                    if(tshipment.SI.isDomestic ==1){
                        console.log('inside domestic' ,tshipment.Domestic)
                        shipmentDomestic.create({
                            "id": 0,
                            "shipmentId": obj.id,
                            "typeOfShipment": tshipment.Domestic.typeOfShipment,
                            "shippingReferenceNumber": tshipment.Domestic.shippingReferenceNumber,
                            "recipent": tshipment.Domestic.recipent,
                            "recipentContact": tshipment.Domestic.recipentContact,
                            "recipentTelNumber": tshipment.Domestic.recipentTelNumber,
                            "carrier": tshipment.Domestic.carrier,
                            "carrierAcNumber": tshipment.Domestic.carrierAcNumber,
                            "bookingNumber": tshipment.Domestic.bookingNumber,
                            "paymentTypeId": tshipment.Domestic.paymentTypeId,
                            "paidBy": tshipment.Domestic.paidBy,
                            "requestedShipDate": tshipment.Domestic.RequestedShipDate,
                            "requestedDeliveryDate": tshipment.Domestic.RequestedDeliveryDate,
                            "cretedOn": null,
                            "createdBy": null,
                            "modifiedOn": "null",
                            "modifiedBy": 0,
                            "active": 1


                        },function(err,objdom){
                            console.log(">>>>>>>>>>>" ,err)
                            if(err){
                                return cb(null , err)
                            }
                        })
                    }
                    else if(tshipment.SI.isDomestic ==0){
                        shipmentInternational.create({
                            "id": 0,
                            "shipmentId":obj.id,
                            "bookingNumber": tshipment.International.bookingNumber,
                            "freightForwarder": tshipment.freightForwarder,
                            "containerTypeId": tshipment.International.containerTypeId,
                            "steamshipLineId": tshipment.International.steamshipLineId,
                            "steamshipVessel": tshipment.International.steamshipVessel,
                            "earliestReturnDate": tshipment.International.EarliestReturnDate,
                            "docCutoffDate": tshipment.International.DocCutoffDate,
                            "cutoffDateNotRequired": 1,
                            "cargoCutoffDate": tshipment.International.CargoCutoffDate,
                            "freeDaysPerContainer": tshipment.International.freeDaysPerContainer,
                            "containerPickupLocation": tshipment.International.containerPickupLocation,
                            "containerReturnLocation": tshipment.International.containerReturnLocation,
                            "notes": tshipment.Domestic.notes,
                            "craetedBy": 0,
                            "createdOn": "2016-10-25",
                            "modifiedBy": 0,
                            "modifiedOn": "2016-10-25",
                            "active": 0

                        },function(err,objdom){
                            if(err){
                                return cb(null , err)
                            }
                        })
                    }

                    if(tshipment.lotInformation.length == 0){
                        return cb(null,err)
                    }
                    else if(tshipment.lotInformation.length == 1){
                        console.log("inside lot" ,tshipment.lotInformation )
                        shipmentLots.create({

                            "id": 0,
                            "shipmentId": obj.id,
                            "piLotsId": tshipment.lotInformation[0].lot_id,
                            "noOfBags": tshipment.lotInformation[0].noOfBags,
                            "confirmedOn": null,
                            "confirmedBy": 1,
                            "queueSequence": 0,
                            "createdOn": null,
                            "createdBy": 0,
                            "modifiedOn": null,
                            "modifiedBy": 0,
                            "active": 0

                        },function(err){
                            if(err){
                                return cb(null , err)
                            }
                        })
                    }
                    else if(tshipment.lotInformation.length > 1){
                        for(var i in tshipment.lotInformation.length) {
                            shipmentLots.create({
                                "id": 0,
                                "shipmentId": obj.id,
                                "piLotsId": tshipment.lotInformation[i].lot_id,
                                "noOfBags": tshipment.lotInformation[i].noOfBags,
                                "confirmedOn": null,
                                "confirmedBy": 1,
                                "queueSequence": 0,
                                "createdOn": null,
                                "createdBy": 0,
                                "modifiedOn": null,
                                "modifiedBy": 0,
                                "active": 1

                            })
                        }
                    }
                }
                if(tshipment.Address.length ==0){
                    return cb(null,err)
                }
                else if(tshipment.Address.length ==1){
                    console.log("inside address")
                    shipmentAddress.create({
                        "id": 0,
                        "shipmentId": obj.id,
                        "shipToAddress": tshipment.Address[0].shippingAddress,
                        "shipToCity": tshipment.Address[0].shippingCity,
                        "shipToZip": tshipment.Address[0].zipCode,
                        "shipToState": tshipment.Address[0].shippingState,
                        "active": 1
                    },function(err){
                        if(err){
                            return cb(null , err)
                        }
                    })
                }
                else if(tshipment.Address.length >1){
                    for(var i in tshipment.Address.length){
                        shipmentAddress.create({
                            "id": 0,
                            "shipmentId": obj.id,
                            "shipToAddress": tshipment.Address[i].shippingAddress,
                            "shipToCity": tshipment.Address[i].shippingCity,
                            "shipToZip": tshipment.Address[i].zipCode,
                            "shipToState": tshipment.Address[i].shippingState,
                            "active": 1
                        },function(err){
                            if(err){
                                return cb(null , err)
                            }
                        })
                    }

                }
            })

    };


    Tshipmentent.remoteMethod('createShipMentEntry', {
        description: 'create createShipMentEntry for Material.',
        accepts: { arg: 'data', type: 'object', http: { source: 'body' }} ,
        returns: {arg: 'Result', type: 'object', root: true},
        http: {path:'/createShipMentEntry', verb: 'post'}
    });



}
