'use strict';

module.exports = function(Tcompany) {

};
