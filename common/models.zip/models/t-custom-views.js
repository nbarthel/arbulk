'use strict';

module.exports = function(Tcustomviews) {

};
