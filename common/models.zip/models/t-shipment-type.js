'use strict';

module.exports = function(Tshipmenttype) {

};
