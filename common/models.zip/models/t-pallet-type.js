'use strict';

module.exports = function(Tpallettype) {

};
