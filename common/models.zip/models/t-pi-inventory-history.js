'use strict';

module.exports = function(Tpiinventoryhistory) {

};
