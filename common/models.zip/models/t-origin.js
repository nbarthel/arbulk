'use strict';

module.exports = function(Torigin) {

};
