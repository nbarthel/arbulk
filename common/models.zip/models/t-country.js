'use strict';

module.exports = function(Tcountry) {

};
