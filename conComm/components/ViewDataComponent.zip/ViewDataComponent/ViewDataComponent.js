/**
 * Created by Anurag on 15-09-2016.
 */


import React from 'react';
import axios from 'axios';
import _ from 'lodash';
import  { PropTypes } from 'react';
import { createDataLoader } from 'react-loopback';
import PackagingInstructionViewForm from '../../containers/Packaging/PackagingInstructionView/PackagingInstructionViewForm';
import HeadBody from './HeadBody'


class ViewDataComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {}
        this.PIData = {}

    }

    componentWillMount() {
        var PIview = createDataLoader(PackagingInstructionViewForm, {
            queries: [{
                endpoint: 'TPackagingInstructions',
                filter: {
                    include : ['TPackagingInstructionLots',{"relation": "TPackagingInstructions", "scope": {"include": ["TLocation"]}}]
                }
            }]
        });
        var base = 'TPackagingInstructionLots';
        //TPackagingInstructionLots
        this.url = PIview._buildUrl(base, {
            include : ['TPackagingInstructions',{"relation": "TPackagingInstructions", "scope": {"include": ["TOrigin" , "TCompany"]}}]
        });
        console.log('sdsddsdsdsdsd' , this.url);


        axios.get(this.url).then((response)=>{
            this.setState({
                viewdata : response.data
            });
           console.log(this.state.viewdata , ">>>>>")
        }).catch(function(error){ debugger;console.log('error is' , error)})


    }
   render(){


  var listData =  _.map(this.state.viewdata , (view)=>{
           return (
           <tbody data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
       <tr  className="base_bg " className="clickable">
           <th colSpan="2"><i className="fa fa-chevron-down" aria-hidden="true"></i> {view.TPackagingInstructions.TLocation.locationName} </th>
           <th colSpan="12"><span>{view.TPackagingInstructions.TCompany.name}</span><span>{view.railcar_number}</span>  </th>
           <th>
               <label className="control control--checkbox">
                   <input type="checkbox" checked="checked" id="row1"/><div className="control__indicator"></div>
               </label>
           </th>
       </tr>

       <tr>
           <td> </td>
           <td> </td>
           <td> </td>
           <td>{view.railcar_number}</td>
           <td>{view.TPackagingInstructions.po_number}</td>
           <td>{view.material}</td>
           <td>{view.status =="CONFIRMED"?'Y':'N'}</td>
           <td>Y</td>
           <td>Y</td>
           <td>5/6/16</td>
           <td>{view.weight}</td>
           <td>{view.bags_to_ship}</td>
           <td>0</td>
           <td>{view.status}</td>
           <td>
               <label className="control control--checkbox">
                   <input type="checkbox" id="row1"/><div className="control__indicator"></div>
               </label>
           </td>
       </tr>
       </tbody>
           )
       }
);

  return(

            <table id="Packaging_Instruction_View" className="table table-expandable table-striped" cellSpacing="0" >

                <HeadBody/>

                {listData}

            </table>

        )
    }
}
export default ViewDataComponent;