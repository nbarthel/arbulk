import React from  'react';
import axios from 'axios';
import _ from  'lodash';
class CustomerNameFilterPage extends React.Component {
    constructor(props){
        super(props);
        this.state={ }
    }
    componentWillMount() {
        axios.get("http://172.31.98.51:8080/api/TCompanies").then((response) => {
        this.setState({
            name: response.data
        })
    })
    .catch(function(err){
        console.log('eroor>>>>' , err)
    })
    }
    render() {
        var customers = _.map(this.state.name,(customer) => {
            return  (<li key={customer.id}>
                    <label className="control control--checkbox">{customer.name}
                    <input type="checkbox" defaultValue="checked" id="row1"/><div className="control__indicator"></div>
                    </label>
                    </li>) 
        })
        return (
            <div className="customer">
                <hr/>
                    <div className="head_bg">
                        <h6 className="pull-left text_left">CUSTOMER  </h6>
                        <a href=""  className="pull-right text_right"> Show All</a>
                    </div>
                    <ul className="scroll">
                        {customers}
                    </ul>
                </div>
        )
    }
}
export default CustomerNameFilterPage;