import React from 'react';
import '../../../public/stylesheets/style.css';
import '../../../public/stylesheets/bootstrap.min.css';
import FilterComponent from '../../../components/ContainerFilterComponent';
import ContainerViewDataComponent from '../../../components/ContainerViewDataComponent/ContainerViewDataComponent';
import FilterButton from '../../../components/ContainerFilterComponent/FilterButton';
import { hashHistory } from 'react-router'
class  ContainerViewForm extends React.Component {
    constructor(props){
        super(props);
            this.status
            this.buttonDisplay = [ ]
            this.checkedCustomer = [ ]
            this.checkedStatus = [ ] 
            this.checkedCompany = [ ]
            this.editId = ''
            this.Query = {}
            this.Where = { }
            this.qArray = []
            this.selected = null
           /*this.conFirmID = null
            this.onClickli = this.onClickli.bind(this)
            this.onClickPo = this.onClickPo.bind(this)
            this.lotSearch = this.lotSearch.bind(this)*/
            this.onCompanyFilter = this.onCompanyFilter.bind(this)
            this.onCustomerFilter =  this.onCustomerFilter.bind(this)
            this.onStatusFilter = this.onStatusFilter.bind(this)
            this.onRemove = this.onRemove.bind(this)
            this.onEdit = this.onEdit.bind(this)
            this.onCheckboxChange = this.onCheckboxChange.bind(this)
        }
         onCompanyFilter(e,location){
            if(e.target.checked){
            this.forceUpdate()
            this.checkedCompany.push(e.target.id)
            Object.defineProperty(this.Where,"Company",{enumerable: true ,
                                                      writable: true,
                                                      configurable:true,
                                                      value:this.checkedCompany})
            this.buttonDisplay.push(e.target.value)
            //console.log(this.props.checkedCompany)
            //console.log(this.props.buttonDisplay)
           
           }
            else if (!e.target.checked){

            let id = e.target.id
            this.checkedCompany = _.without(this.checkedCompany,id)
            this.Where.Company = this.checkedCompany
            if(Object.keys(this.Where.Company).length === 0){
              this.Where.Company = undefined
              //console.log(this.Where)
              delete this.Where.Company
             }
                let value = e.target.value               
                let index = this.buttonDisplay.indexOf(e.target.value)
                if(index !== -1)
                this.buttonDisplay = _.without(this.buttonDisplay,value)       
                 this.forceUpdate() 
                   }
        }
        onCustomerFilter(e,customer){
            if(e.target.checked){
            this.forceUpdate()
            this.checkedCustomer.push(e.target.id)
            Object.defineProperty(this.Where,"Customer",{enumerable: true ,
                                                      writable: true,
                                                      configurable:true,
                                                      value:this.checkedCustomer})
            this.buttonDisplay.push(e.target.value)
            //console.log(this.props.checkedCompany)
            //console.log(this.props.buttonDisplay)
            console.log(this.checkedCustomer)
           }
            else if (!e.target.checked){
            let id = e.target.id
            this.checkedCustomer = _.without(this.checkedCustomer,id)
            this.Where.Customer = this.checkedCustomer
            if(Object.keys(this.Where.Customer).length === 0){
              this.Where.Customer = undefined
              delete this.Where.Customer
            }
                let value = e.target.value
                let index = this.buttonDisplay.indexOf(e.target.value)
                if(index !== -1)
                this.buttonDisplay = _.without(this.buttonDisplay,value)       
                  this.forceUpdate()
                   }
        }
        onStatusFilter(e,status){
            if(e.target.checked){

            this.checkedStatus.push(e.target.value);
            Object.defineProperty(this.Where,"status",{enumerable: true ,
                                                      writable: true,
                                                      configurable:true,
                                                      value:this.checkedStatus})
            this.buttonDisplay.push(e.target.value)
            this.forceUpdate()
            
            //console.log(this.props.buttonDisplay)
           /* console.log(this.Where)
            console.log(this.checkedStatus)
            console.log(this.checkedStatus.length)*/
           }
            else if (!e.target.checked){
            let value = e.target.value
            //let pos = this.checkedStatus.indexOf(e.target.value)
            this.checkedStatus = _.without(this.checkedStatus,value)
            this.Where.status = this.checkedStatus
            //console.log(this.Where.status)
            if(Object.keys(this.Where.status).length === 0){
              this.Where.status = undefined
              delete this.Where.status
            }
            console.log(this.Where)
            //let value = e.target.value
                let index = this.buttonDisplay.indexOf(e.target.value)
                if(index !== -1)
                this.buttonDisplay = _.without(this.buttonDisplay,value) 
                //console.log(this.buttonDisplay)      
                  this.forceUpdate()
                  }
        }
    onButtonRemove(index,button){
    this.buttonDisplay.splice(index,1)
    this.forceUpdate()

}
    onRemove(e){
        debugger;
        console.log("clicked")
        console.log("WHERE",this.Where)
         this.buttonDisplay = [];
         //this.buttonDisplay = []
            this.checkedCustomer = []
            this.checkedStatus = []
            this.checkedCompany = []
            this.Query = []
            delete this.Where.Company 
            delete this.Where.Customer 
            delete this.Where.status  
            //delete this.state.viewData
            /*this.setState({
                key : this.state.key +1,
                index : this.state.index +1
            })*/
            document.getElementById('customer_name').selectedIndex = 0
         this.forceUpdate();

    }
    onCheckboxChange(e,data){
        this.editId = data.id
        console.log("DATA",data)

    }
    onEdit(e){
        hashHistory.push('Container/containeredit/'+this.editId)
    }
    render(){
        return(
            <section className="side-filter">
                <div className="menu-bg hidden-md hidden-lg hidden-sm  visible-xs-block">
                    <div className="">
                        <h4 className="pull-left">REFINE YOUR RESULT </h4>
                        <button type="button" className="btn collapsed pull-right " data-toggle="collapse" data-target="#filter-menu" aria-expanded="false"><i className="fa fa-caret-down fa-2x" aria-hidden="true"></i></button>
                    </div>
                </div>
                <div className="container">
                    <div className="row-fluid">
    <FilterComponent  onCompanyFilter = {this.onCompanyFilter} onCustomerFilter = {this.onCustomerFilter} onTextChange = {this.onTextChange}  onStatusFilter = {this.onStatusFilter}/>
<div id="filter-grid">
<div className="col-md-12 col-lg-12 col-sm-12 col-xs-12 pddn-20-top pull-right">
<div className="row">
   <FilterButton buttonDisplay = {this.buttonDisplay}  onButtonRemove = {this.onButtonRemove} onRemove = {this.onRemove} Query = {this.Query} onSearch = {this.onSearch}/>
    <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12 padding-top-btm-xs">
        <div className="pull-right ">
            <select className="form-control"   id="customer_name" name="customer_name">
                <option value="">Save View</option>
                <option value="View1">View 1</option>
                <option value="View2">View 2</option>
                <option value="View3">View 3</option>
                <option value="View4">View 4</option>
                <option value="View5">View 5</option>
            </select>
        </div>
        <div className="pull-right btn_right_margin">
            <select className="form-control"  id="customer_name" name="customer_name">
                <option value="">Group By</option>
                <option value="Date">Date</option>
            </select>
        </div>
    </div>
    <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 "><hr/></div>
    <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div className="table-responsive view_table viewLoad">
           <ContainerViewDataComponent onCheckboxChange = {this.onCheckboxChange}/>
        </div>
        <div className="row-fluid pddn-50-btm padding-top-btm-xs">
            <div className="pull-left margin-10-last-l"><button type="button"  className="btn  btn-primary">Print BOL</button></div>
            <div className="pull-left margin-10-all"><button type="button"  className="btn  btn-primary">Print Load Order</button></div>
            <div className="pull-left margin-10-all"><button type="button"  className="btn  btn-gray">Add to Queue</button></div>
            <div className="pull-right margin-10-last-r"><button type="button"  className="btn  btn-success">View</button></div>
            <div className="pull-right margin-10-all"><button type="button" id="edit_btn"  className="btn  btn-orange" onClick = {this.onEdit}>EDIT</button></div>
        </div>
        <div className="row pddn-50-btm">
            <div  className="col-lg-12 col-md-12 col-sm-12 col-xs-12"><hr/></div>
            <div className="col-lg-4 col-sm-4 col-md-4 col-xs-12 ">
                <input type="text" className="form-control" id="No_of_Bages_Pallat" placeholder="Enter Customer Screen Name "/>
            </div>
            <div className="col-lg-4 col-sm-4 col-md-4 col-xs-12 padding-top-btm-xs">
                <button type="button"   className="btn  btn-success margin-left-xs">SAVE CUSTOMER VIEW</button>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
</section>

                                                        )
    }
}
export default ContainerViewForm;

