/**
 * Created by Anurag on 15-09-2016.
 */
'use strict';

import React from 'react';
import axios from 'axios';
import _ from 'lodash';
import  { PropTypes } from 'react';
import { createDataLoader } from 'react-loopback';
//import PackagingInstructionViewForm from '../../containers/Packaging/PackagingInstructionView/PackagingInstructionViewForm';
import HeadBody from './HeadBody';
import NestedRows from './NestedRows'
import request from '../../utils/request';
import { Base_Url } from '../../constants'
var moment = require('moment');
/*import './js/jquery.dataTables.min.js';
*//*import './stylesheet/jquery.dataTables.min.css'*/
var Loader = require('react-loader');

class ContainerViewDataComponent extends React.Component{
    
    constructor(props){
        super(props);
        this.isAsc = false
        this.state = {
        loaded : false 
        }
        
        this.PIData = { }
        this.myObj = { }
        this.qArray = []
        this.checkclick = this.checkclick.bind(this);
        //this.onAscending = this.onAscending.bind(this)   
        this.onToggel = this.onToggel.bind(this) 
        this.onClickRow = this.onClickRow.bind(this)
      }
componentWillMount(){
   let id = this.props.id
      if(this.props.id != undefined){
        var PIview = createDataLoader(ContainerViewDataComponent,{
           queries:[{
           endpoint: 'TPackagingInstructions',
              filter: {
              include: ['TPackagingInstructionLots',{"relation":"TPackagingInstructions","scope":{"include":["TLocation"]}}]
             }
        }]
      })
    console.log("I have recieved props",)
    //debugger
   
    var base = 'TPackagingInstructions'+'/'+id;
    this.url = PIview._buildUrl(base, {
      include: ['TPackagingInstructionLots',"TLocation","TCompany"]
    })
    console.log(this.url,"<<<<<<<<<<<<<<<<<<<<URL")
      
      $.ajax({
            url: this.url,
            success:function(data){
                console.log('ajax ',data);
              this.setState({
                  viewData : [data],
                  loaded:true
                })
          }.bind(this)

        })

   axios.get(Base_Url+"TPackagingInstructionLots/getMaxQueue").then(response=>{
    debugger;
    this.setState({
        queue_Sequence : response.data
    })
})




    }
   else {
    debugger
  var PIview = createDataLoader(ContainerViewDataComponent,{
      queries:[{
        endpoint: 'TPackagingInstructions',
        filter: {
          include: ['TPackagingInstructionLots',{"relation":"TPackagingInstructions","scope":{"include":["TLocation"]}}]
        }
      }]
    })
       var base = 'TShipmentents';
        //TPackagingInstructionLots
        this.url = PIview._buildUrl(base, {
             "include" : ["TContainerDomestic","TContainerInternational","TCompany" ,"TLocation","TShipmentDomestic","TShipmentInternational"]


        });
        console.log('sdsddsdsdssdssssssssssd' , this.url);
      $.ajax({
            url: this.url,
            success:function(data){
                console.log('ajax ',data);
                debugger
               this.setState(
                   {
                       viewData : data,
                       loaded:true
                   }
               )
               //console.log( this.state.xyz)
        }.bind(this)
        })

     axios.get(Base_Url+"TPackagingInstructionLots/getMaxQueue").then(response=>{
    debugger;
    this.setState({
        queue_Sequence : response.data
    })
})


    }  
  }
componentDidMount() {
  debugger
   $(document).ready(function()
   { 
    var table = $('#Packaging_Instruction_View').DataTable({
      colReorder: true
    });
    
   } );
}
checkclick(data,value)
{
    
    var queueArray = []
    this.qArray.push(value.id)
    localStorage.setItem('qArray',this.qArray)
    localStorage.setItem('queue_Sequence',this.state.queue_Sequence[0].max_mark)
    console.log("clicked>>>>>>>>" ,value)
}

onAscending(e,head){
var sortedData;
if(this.isAsc == false)
{
var switchvalue = head;
var PIview = createDataLoader(ContainerViewDataComponent,{
      queries:[{
        endpoint: 'TPackagingInstructions',
        filter: {
          include: ['TPackagingInstructionLots',{"relation":"TPackagingInstructions","scope":{"include":["TLocation"]}}]
        }
      }]
    })
       var base = 'TPackagingInstructions';
        //TPackagingInstructionLots
        this.url = PIview._buildUrl(base, {
            include : ['TPackagingInstructionLots',"TLocation" , "TCompany"]


        });
        console.log('sdsddsdsdssdssssssssssd' , this.url);
      $.ajax({
            url: this.url,
            success:function(data){
                console.log('ajax ',data);
                debugger
               this.sortedadta = 
                   {
                       viewData : data
                   }
               
               this.isAsc = true;

                            switch(switchvalue) {
                            case 'po_number':
                           sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                            return item.po_number;
                           });
                           this.setState({
                           viewData  : sortedData
                                   }) 
                             break;
                   case 'lot_number':
                     sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                     return (item.TPackagingInstructionLots[0]? item.TPackagingInstructionLots[0].lot_number : '');
                     });
                     this.setState({
                           viewData  : sortedData
                                   }) 
                       break;
                               case 'railcar_number':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return (item.TPackagingInstructionLots[0]? item.TPackagingInstructionLots[0].railcar_number : '');
                                });
                      this.setState({
                           viewData  : sortedData
                                   }) 
                      break;
                       case 'weight':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return (item.TPackagingInstructionLots[0]? item.TPackagingInstructionLots[0].weight : '');
                                });
                      this.setState({
                           viewData  : sortedData
                                   }) 
                      break;
                      case 'location':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return item.TLocation.locationName;
                                });
                      this.setState({
                           viewData  : sortedData
                                   }) 
                      break;
                      case 'company':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return item.TCompany.name;
                                });
                      this.setState({
                           viewData  : sortedData
                                   }) 
                      break;
    default:
        this.state.viewData
}



        }.bind(this)
        })

    axios.get(Base_Url+"TPackagingInstructionLots/getMaxQueue").then(response=>{
    
    this.setState({
        queue_Sequence : response.data
    })
})
}

else{

var switchvalue = head;
var PIview = createDataLoader(ContainerViewDataComponent,{
      queries:[{
        endpoint: 'TPackagingInstructions',
        filter: {
          include: ['TPackagingInstructionLots',{"relation":"TPackagingInstructions","scope":{"include":["TLocation"]}}]
        }
      }]
    })
       var base = 'TPackagingInstructions';
        //TPackagingInstructionLots
        this.url = PIview._buildUrl(base, {
            include : ['TPackagingInstructionLots',"TLocation" , "TCompany"]


        });
        console.log('sdsddsdsdssdssssssssssd' , this.url);
      $.ajax({
            url: this.url,
            success:function(data){
                console.log('ajax ',data);
                debugger
               this.sortedadta = 
                   {
                       viewData : data
                   }
               
               this.isAsc = false;

                            switch(switchvalue) {
                            case 'po_number':
                           sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                            return item.po_number;
                           });
                           this.setState({
                           viewData  : sortedData.reverse()
                                   }) 
                             break;
                   case 'lot_number':
                     sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                     return (item.TPackagingInstructionLots[0]? item.TPackagingInstructionLots[0].lot_number : '');
                     });
                     this.setState({
                           viewData  : sortedData.reverse()
                                   }) 
                       break;
                      case 'railcar_number':
                      sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                     return (item.TPackagingInstructionLots[0]? item.TPackagingInstructionLots[0].railcar_number : '');
});
                      this.setState({
                           viewData  : sortedData.reverse()
                                   }) 
                      break;
                      case 'weight':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return (item.TPackagingInstructionLots[0]? item.TPackagingInstructionLots[0].weight : '');
                                });
                      this.setState({
                           viewData  : sortedData.reverse()
                                   }) 
                      break;
                       case 'location':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return item.TLocation.locationName;
                                });
                      this.setState({
                           viewData  : sortedData.reverse()
                                   }) 
                      break;
                      case 'company':
                                sortedData = _.sortBy(this.sortedadta.viewData, function(item) {
                                return item.TCompany.name;
                                });
                      this.setState({
                           viewData  : sortedData.reverse()
                                   }) 
                      break;
    default:
        this.state.viewData
}



        }.bind(this)
        })

    axios.get(Base_Url+"TPackagingInstructionLots/getMaxQueue").then(response=>{
    
    this.setState({
        queue_Sequence : response.data
    })
})
}
}
onToggel(e ,elm){
console.log('>>>>>>' , $(elm))

  debugger; 
  $( "button" ).click(function() {
  $( "p" ).slideToggle( "slow" );
});
}

onClickRow(e){

           var rowObj = $(this.refs.clickable)
            //var aa= rowObj.attr('data-target')
            var aa = e.target.getAttribute('data-target')
            //$('#Packaging_Instruction_View').find('.'+aa).toggleClass('hide')
       

      if($('#Packaging_Instruction_View').find('.'+aa).length > 2)
      {
        $('#Packaging_Instruction_View').find('.'+aa).each(function(index){
           $('#Packaging_Instruction_View').find('.'+aa).toggleClass('hide')


        })
      } 

        else if($('#Packaging_Instruction_View').find('.'+aa).length ==2)
{
        for(var i in $('#Packaging_Instruction_View').find('.'+aa))
        {

         $('#Packaging_Instruction_View').find('.'+aa).toggleClass('hide')
             }
         }
         else{
           $('#Packaging_Instruction_View').find('.'+aa).toggleClass('hide')
         }
 }



render(){
  debugger;
        
       var filterData = this.props.filterData ;

     /* if(filterData.constructor === Array)
      {
           this.state.viewData = filterData
       }*/
      
      var selectedWeight = this.props.weight;
      
debugger
      console.log("<<<<<^^>>>>>",this.state.viewData)
      
      var listData =  _.map(this.state.viewData,(view,index)=>{
        debugger
        var bookingNumber = ''
        var Arr  = ''
        var steamShip = ''
        if(view.TContainerDomestic.length > 0 || view.TContainerInternational.length > 0){
        if(view.isDomestic == 1){
           if(view.TShipmentDomestic.length > 0){
            bookingNumber = view.TShipmentDomestic[0].bookingNumber
          }
          if(view.TContainerDomestic.length > 0){
           var Arrived = view.TContainerDomestic[0].containerArrived
           if(Arrived == 1){
            Arr = 'YES'
            }
            else{
              Arr = 'NO'
            }
          }
        }
        else {
          if(view.TShipmentInternational.length > 0){
            bookingNumber = view.TShipmentInternational[0].bookingNumber
          }
          if(view.TContainerInternational.length > 0){
            var Arrived = view.TContainerInternational[0].containerArrived
            if(Arrived == 1){
              Arr = 'YES'
            }
            else{
              Arr = 'NO'
            }
          }
          if(view.TContainerInternational.length > 0){
            var steamLine = view.TContainerInternational[0].containerSteamshipLineConfirmed
            if(steamLine == 1){
              steamShip = 'YES'
            }
            else{
              steamShip = 'NO'
            }
          }
        }
        
      
      var count = index
      return (
       <thead key={index} >
       <tr  className="base_bg clickable" ref ="clickable">
           <th style ={{display : this.props.showARB}}> <i className="fa fa-chevron-down" aria-hidden="false" data-target ={count}  onClick={(e) => {this.onClickRow(e)}}></i> {view.TLocation ? view.TLocation.locationName : ''} </th>
           <th style ={{display : this.props.showCustomer}}> {view.TCompany ? view.TCompany.name : ''}</th>           
           <th style ={{display : this.props.showPO}}></th>
           <th style ={{display : this.props.Railcar}}></th>
           <th style ={{display : this.props.showMaterial}}></th>
           <th style ={{display : this.props.showConfmd}}></th>
           <th style ={{display : this.props.showArrvd}}></th>
           <th style ={{display : this.props.showRecd}}></th>
           <th></th>
           <th>
               <label className="control control--checkbox">
                   <input type="checkbox" onChange={(e)=>{this.props.headerCheckboxChange(e,view)}} value={view.id}  id={view.id}/><div className="control__indicator"></div>
               </label>
           </th>
       </tr>
        <tr key={index} className ={count}>
                   <td style ={{display : this.props.showARB}}> </td>
                   <td style ={{display : this.props.showCustomer}}> </td>
                   <td style ={{display : this.props.showPO}}>{view.releaseNumber} </td>
                   <td style ={{display : this.props.Railcar}}>{bookingNumber ? bookingNumber : 'N/A'}</td>
                   <td style ={{display : this.props.showLot}}>{view.TContainerInternational.length > 0 ? view.TContainerInternational[0].containerNumber : view.TContainerDomestic[0].containerNumber}</td>
                   <td style ={{display : this.props.showMaterial}}>{'N/A'}</td>
                   <td style ={{display : this.props.showConfmd}}>{Arr ? Arr : 'No'}</td>
                   <td style ={{display : this.props.showArrvd}}>{steamShip ? steamShip : 'N/A'}</td>
                   <td style ={{display : this.props.showRecd}}></td>
                   <td>
                   <label className="control control--checkbox">
                   <input type="checkbox"  onClick={(e) => this.checkclick(e,view)}   onChange={(e)=>{this.props.onCheckboxChange(e,view)}} value={view.id} id={''}/><div className="control__indicator"></div>
                   </label>
                   </td>
        </tr>
       
      

       </thead>

    
           )
       }}
  )
 return(
 <Loader loaded={this.state.loaded}>
 <table id="Packaging_Instruction_View" className="table table-expandable table-striped" cellSpacing="0" >
             <thead className="table_head">
           <tr className="sorting_head" >
               <th style = {{display : this.props.showARB}} onClick={(e)=> this.onAscending(e,'location')}>ARB 
                    <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                    </span>
               </th>
               <th style = {{display : this.props.showCustomer}} onClick={(e)=> this.onAscending(e,'company')}>Customer 

                        <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 

               </th>
               <th style ={{display : this.props.showPO}} onClick={(e)=> this.onAscending(e,'po_number')}>Release#
                 <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 
               </th>
               <th style ={{display : this.props.Railcar}} onClick={(e)=> this.onAscending(e,'railcar_number')}>Booking#
               <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 
                </th>
               <th style ={{display : this.props.showLot}} onClick={(e)=> this.onAscending(e,'lot_number')}>Container#
                <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 
                
               </th>
               <th style ={{display : this.props.showMaterial}} onClick={(e)=> this.onAscending(e,'po_number')}>Trucker
               <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 
                
               </th>
               <th style ={{display : this.props.showConfmd}} onClick={(e)=> this.onAscending(e,'po_number')}>Arrived?
               <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span>                
               </th>
               <th style ={{display : this.props.showArrvd}} onClick={(e)=> this.onAscending(e,'po_number')}>Steamship Line
                <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 
                
               </th>
               <th style ={{display : this.props.showRecd}} onClick={(e)=> this.onAscending(e,'po_number')}>Type
                <span className="fa-stack ">
                        <i className="fa fa-sort-asc fa-stack-1x" ></i>
                        <i className="fa fa-sort-desc fa-stack-1x"></i>
                </span> 
                
               </th>
               <th>
                 
               </th>
             </tr>
           </thead>
                {listData}
        </table>
        </Loader>)
  }
}
export default ContainerViewDataComponent;
