import React from 'react';
import validateInput from '../../public/validations/validateInput';
import '../../public/stylesheets/style.css';

class ForgotPasswordForm extends React.Component{
		constructor(){
			super();
			this.state={
				newPassword:'',
				confirmPassword:'',
				errors:{}
			}
			this.onChange = this.onChange.bind(this);
			this.onSubmit = this.onSubmit.bind(this);
		}
		onChange(e){
			this.setState({[e.target.name] : e.target.value});
		}
		isValid(){
			const { errors , isValid } = validateInput(this.state);
			if(!isValid){
				this.setState({errors});
			}
			return isValid;
		}
		onSubmit(e){
			e.preventDefault();
			if(this.isValid()){
				this.setState({errors:{}});
			}
		}

	render(){
		return(
	<section className="body_section">  
	<div className="container">  
	<div className="set-password col-lg-8 col-md-8 col-sm-12 col-xs-12">
	<form className="form-horizontal bs-component" onSubmit={this.onSubmit}>
	<fieldset className="scheduler-border">
	<legend className="scheduler-border">SET NEW PASSWORD</legend>
				
				<div className="form-group ">
					<label htmlFor="inputPassword" 
					className="col-lg-4 control-label">New Password</label>
					<div className="col-lg-8">
					  <input 
					  type="password" 
					  className="form-control  input-lg" 
					  id="inputPassword"
					  placeholder="Enter New Password"
					  name="newPassword"
					  value={this.state.newPassword}
					  onChange={this.onChange} />
					  <div className="error">
					  <span></span>
					  </div>
					</div>
                </div>
				
				<div className="form-group">
					<label htmlFor="inputPassword"
					className="col-lg-4 control-label">Confirm Password</label>
					<div className="col-lg-8">
					<input type="password"
					 className="form-control  input-lg"
					 id="inputPassword"
					 value={this.state.confirmPassword}
					 name="confirmPassword"
					 placeholder="Confirm Password"
					 onChange={this.onChange} />
					<div className="error">
					<span></span>
					</div>
					</div>
                </div>
			  
			</fieldset>
			
			<div className="form-group">
			<div className="col-lg-12 ">
			<button type="submit"
			className="btn  btn-primary">UPDATE PASSWORD</button>
			</div>
			</div>	
		</form>	
	</div>
	
 </div>		
</section>
			)
	}
}
export default ForgotPasswordForm;