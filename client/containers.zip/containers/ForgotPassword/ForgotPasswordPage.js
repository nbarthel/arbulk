import React from 'react';
import ForgotPasswordForm from './ForgotPasswordForm';

class ForgotPasswordPage extends React.Component{

	render(){
		return(
			<div>
			<ForgotPasswordForm />
			</div>
			)
	}
}
export default ForgotPasswordPage;