import React from 'react';
import PackagingInstructionEditForm from './PackagingInstructionEditForm';

class PackagingInstructionEditPage extends React.Component{

	render(){
		return(
			<div>
			<PackagingInstructionEditForm />
			</div>	
			)
	}
}

export default PackagingInstructionEditPage;